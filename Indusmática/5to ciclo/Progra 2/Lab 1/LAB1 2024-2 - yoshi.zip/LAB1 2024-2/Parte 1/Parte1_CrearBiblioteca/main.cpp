/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 10 de abril de 2025, 18:17
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Estructuras.h"
#include "FuncionesPrueba.h"

void leer(const char* nomArch, struct Plato *platos){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    int i=0;
    while(true){
        archLee>>platos[i];
        if (archLee.eof()) break;
        else i++;
    }
    strcpy(platos[i].codigo,"FIN");
}

void leer(const char* nomArch, struct Repartidor *repartidores){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    int i=0;
    while(true){
        archLee>>repartidores[i];
        if (archLee.eof()) break;
        else i++;
    }
    strcpy(repartidores[i].codigo,"FIN");
}

void leer(const char* nomArch, struct Plato *platos, struct Repartidor *repartidores){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    struct Pedido pedido;
    while(true){
        archLee>>pedido;
        pedido<=platos;
        repartidores<=pedido;
        if (archLee.eof()) break;
    }
}

void procesar_repartidores(struct Repartidor *repartidores){
    for (int i = 0; strcmp(repartidores[i].codigo,"FIN")!=0; i++) {
        for (int j = 0; j < repartidores[i].cantidadDeOrdenes; j++)
            !repartidores[i].ordenesDeCompra[j];
        !repartidores[i];
    }
}

void imprimir(const char* nomArch, struct Plato *platos, struct Repartidor *repartidores){
    ofstream archRep(nomArch,ios::out);
    if (not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    archRep<<"REPORTE DE PLATOS"<<endl;
    for (int i = 0; strcmp(platos[i].codigo,"FIN")!=0; i++) {
        archRep<<platos[i];
    }
    archRep<<endl<<"REPORTE DE REPARTIDORES"<<endl;
    for (int i = 0; strcmp(repartidores[i].codigo,"FIN")!=0; i++) {
        archRep<<repartidores[i];
    }
}

int main(int argc, char** argv) {
    struct Plato platos[30]{};
    struct Repartidor repartidores[10]{};
    leer("PLatosOfrecidosPrueba.csv", platos);
    leer("RepartidoresContratadosPrueba.csv",repartidores);
    leer("OrdenesDeCompraPrueba.txt",platos,repartidores);
    procesar_repartidores(repartidores);
    imprimir("Pruebas.txt",platos,repartidores);
    return 0;
}

