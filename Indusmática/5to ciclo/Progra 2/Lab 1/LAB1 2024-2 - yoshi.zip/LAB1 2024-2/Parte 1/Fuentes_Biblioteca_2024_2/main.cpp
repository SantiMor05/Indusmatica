/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 9 de abril de 2025, 13:35
 */

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include "Estructuras.h"
#include "FuncionesPrueba.h"
/*
 * 
 */
int main(int argc, char** argv) {
    struct Plato platos[30]{};
    struct Repartidor repartidores[10]{};
    leer("PLatosOfrecidosPrueba.csv", platos);
    leer("RepartidoresContratadosPrueba.csv",repartidores);
    leer("OrdenesDeCompraPrueba.txt",platos,repartidores);
    procesar_repartidores(repartidores);
    imprimir("Pruebas.txt",platos,repartidores);
    return 0;
}

