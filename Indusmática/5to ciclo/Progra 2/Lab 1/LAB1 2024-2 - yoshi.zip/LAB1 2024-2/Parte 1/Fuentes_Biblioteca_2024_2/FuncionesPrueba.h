/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   FuncionesPrueba.h
 * Author: Usuario
 *
 * Created on 9 de abril de 2025, 13:48
 */

#ifndef FUNCIONESPRUEBA_H
#define FUNCIONESPRUEBA_H

void leer(const char* nomArch, struct Plato *platos);
void leer(const char* nomArch, struct Repartidor *repartidores);
void leer(const char* nomArch, struct Plato *platos, struct Repartidor *repartidores);
void imprimir(const char* nomArch, struct Plato *platos, struct Repartidor *repartidores);
void procesar_repartidores(struct Repartidor *repartidores);

void operator >>(ifstream &arch, struct Plato &plato);
void operator >>(ifstream &arch, struct Repartidor &repartidor);
void operator>>(ifstream &arch, struct Pedido &pedido);
bool operator <=(struct Pedido &pedido, struct Plato *arrPlatos);
void operator <=(struct Repartidor *arrRepart, struct Pedido pedido);
void ingresar_orden(struct Pedido pedido, struct Repartidor &repartidor);
void asignar_plato(struct Pedido pedido,struct OrdenDeCompra &orden);
void operator !(struct OrdenDeCompra &orden);
double evaluar_distancia(double distancia);
void operator !(struct Repartidor &repartidor);
void operator <<(ofstream &arch, struct Plato plato);
void operator <<(ofstream &arch, struct Repartidor repartidor);
void imprimir_platos(ofstream &arch, struct OrdenDeCompra &orden);

#endif /* FUNCIONESPRUEBA_H */

