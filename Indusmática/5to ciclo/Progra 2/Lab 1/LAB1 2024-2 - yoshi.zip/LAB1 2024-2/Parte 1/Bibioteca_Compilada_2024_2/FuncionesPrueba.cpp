/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Estructuras.h"
#include "FuncionesPrueba.h"


void operator >>(ifstream &arch, struct Plato &plato){
    arch.getline(plato.codigo,7,',');
    if (arch.eof()) return;
    arch.getline(plato.nombre,60,',');
    arch>>plato.precio;
    arch.get();
    while(arch.get()!='\n');
}

void operator >>(ifstream &arch, struct Repartidor &repartidor){
    arch.getline(repartidor.codigo,7,',');
    if (arch.eof()) return;
    arch.getline(repartidor.nombre,60,',');
    arch.getline(repartidor.tipoDeVehiculo,15);
}

void operator>>(ifstream &arch, struct Pedido &pedido){
    arch>>pedido.dniDelCliente;
    if (arch.eof()) return;
    arch>>pedido.codigoDelPlato;
    arch>>pedido.cantidad;
    arch>>pedido.codigoDelRepartidor;
    arch>>pedido.distanciaARecorrer;
}

bool operator <=(struct Pedido &pedido, struct Plato *arrPlatos){
    for (int i = 0; strcmp(arrPlatos[i].codigo,"FIN")!=0; i++)
        if (strcmp(pedido.codigoDelPlato,arrPlatos[i].codigo)==0){
            arrPlatos[i].totalDePedidos += pedido.cantidad;
            arrPlatos[i].totalRecaudado += arrPlatos[i].precio*pedido.cantidad;
            pedido.precio = arrPlatos[i].precio;
            return true;
        }
    return false;
}

void operator <=(struct Repartidor *arrRepart, struct Pedido pedido){
    for (int i = 0; strcmp(arrRepart[i].codigo,"FIN")!=0; i++)
        if (strcmp(pedido.codigoDelRepartidor,arrRepart[i].codigo)==0){
            ingresar_orden(pedido,arrRepart[i]);
            return;
        }
}

void ingresar_orden(struct Pedido pedido, struct Repartidor &repartidor){
    int i=0;
    for (i = 0; i < repartidor.cantidadDeOrdenes; i++)
        if (pedido.dniDelCliente==repartidor.ordenesDeCompra[i].dniDelCliente){
            asignar_plato(pedido,repartidor.ordenesDeCompra[i]);
            return;
        }
    //no lo encontró, se agrega
    repartidor.ordenesDeCompra[i].distancia = pedido.distanciaARecorrer;
    repartidor.ordenesDeCompra[i].dniDelCliente = pedido.dniDelCliente;
    repartidor.cantidadDeOrdenes++;
    asignar_plato(pedido,repartidor.ordenesDeCompra[i]);
    repartidor.ordenesDeCompra[i].cantidadDePlatos = 1;
}

void asignar_plato(struct Pedido pedido, struct OrdenDeCompra &orden){
    int i=0;
    for (i = 0; i < orden.cantidadDePlatos; i++)
        if (strcmp(pedido.codigoDelPlato,orden.platosSolicitados[i].codigo)==0){
            orden.platosSolicitados[i].cantidad += pedido.cantidad;
            return;
        }
    // no lo enocntró, se agrega
    orden.platosSolicitados[i].cantidad = pedido.cantidad;
    strcpy(orden.platosSolicitados[i].codigo,pedido.codigoDelPlato);
    orden.platosSolicitados[i].precio = pedido.precio;
    orden.cantidadDePlatos++;
}

void operator !(struct OrdenDeCompra &orden){
    for (int i = 0; i < orden.cantidadDePlatos; i++) {
        orden.montoPorCobrar += orden.platosSolicitados[i].cantidad*orden.platosSolicitados[i].precio;
    }
    orden.pagoPorEnvio = evaluar_distancia(orden.distancia);
}

double evaluar_distancia(double distancia){
    if (distancia<8){
        return 10,5;
    }
    else if(distancia<=12){
            return 14.8;
        }
        else if(distancia<=20){
                return 23.60;
            }
        else return 31.70;
}

void operator !(struct Repartidor &repartidor){
    for (int i = 0; i < repartidor.cantidadDeOrdenes; i++) {
        repartidor.pagoPorEntregas += repartidor.ordenesDeCompra[i].pagoPorEnvio;
    }
}

void operator <<(ofstream &arch, struct Plato plato){
    arch.precision(2);
    arch<<fixed;
    arch<<plato.codigo<<"   "<<left<<setw(65)<<plato.nombre<<right<<setw(8)<<
            plato.precio<<setw(8)<<plato.totalDePedidos<<setw(10)<<plato.totalRecaudado
            <<endl;
}

void operator <<(ofstream &arch, struct Repartidor repartidor){
    arch.precision(2);
    arch<<fixed;
    arch<<repartidor.codigo<<"   "<<left<<setw(70)<<repartidor.nombre<<right<<
            setw(15)<<repartidor.tipoDeVehiculo<<setw(10)<<repartidor.pagoPorEntregas<<endl;
    arch<<"ORDENES ENTREGADAS"<<endl;
    for (int i = 0; i < repartidor.cantidadDeOrdenes; i++) {
        arch<<setw(20)<<repartidor.ordenesDeCompra[i].dniDelCliente<<setw(8)<<
                repartidor.ordenesDeCompra[i].distancia<<setw(10)<<
                repartidor.ordenesDeCompra[i].montoPorCobrar<<setw(10)<<
                repartidor.ordenesDeCompra[i].pagoPorEnvio<<endl;
        arch<<"Platos solicitados: "<<endl;
        imprimir_platos(arch,repartidor.ordenesDeCompra[i]);
    }
}

void imprimir_platos(ofstream &arch, struct OrdenDeCompra &orden){
    for (int i = 0; i < orden.cantidadDePlatos; i++) {
        arch<<" - "<<orden.platosSolicitados[i].codigo<<setw(8)<<
                orden.platosSolicitados[i].precio<<setw(5)<<
                orden.platosSolicitados[i].cantidad<<setw(10)<<
                orden.platosSolicitados[i].cantidad*orden.platosSolicitados[i].precio<<endl;
    }
}
