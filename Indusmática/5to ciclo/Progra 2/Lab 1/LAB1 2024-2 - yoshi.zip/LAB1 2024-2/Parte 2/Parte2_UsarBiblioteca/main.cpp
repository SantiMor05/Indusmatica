/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 10 de abril de 2025, 18:31
 */

#include <cstdlib>
#include <fstream>
#include <cstring>
using namespace std;
#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "FuncionesPrueba.h"


int main(int argc, char** argv) {
    ifstream archLee, archRP, archPD;
    ofstream archRep;
    struct Plato arrPlatos[150]{};
    struct Repartidor arrReps[150]{};
    int i;
    AperturaDeUnArchivoDeTextosParaLeer(archLee,"PlatosOfrecidos.csv");
    i=0;
    while(true){
        archLee>>arrPlatos[i];
        if (archLee.eof()) break;
        else i++;
    }
    strcpy(arrPlatos[i].codigo,"FIN");
    AperturaDeUnArchivoDeTextosParaLeer(archRP,"RepartidoresContratados.csv");
    i=0;
    while(true){
        archRP>>arrReps[i];
        if (archRP.eof()) break;
        else i++;
    }
    strcpy(arrReps[i].codigo,"FIN");
    AperturaDeUnArchivoDeTextosParaLeer(archPD,"OrdenesDeCompra.txt");
    struct Pedido pedido;
    while(true){
        archPD>>pedido;
        if (archPD.eof()) break;
        pedido<=arrPlatos;
        arrReps<=pedido;
    }
    for (int i = 0; strcmp(arrReps[i].codigo,"FIN")!=0; i++) {
        for (int j = 0; j < arrReps[i].cantidadDeOrdenes; j++)
            !arrReps[i].ordenesDeCompra[j];
        !arrReps[i];
    }
    AperturaDeUnArchivoDeTextosParaEscribir(archRep,"Reporte.txt");
    archRep<<"REPORTE DE PLATOS"<<endl;
    for (int i = 0; strcmp(arrPlatos[i].codigo,"FIN")!=0; i++) {
        archRep<<arrPlatos[i];
    }
    archRep<<endl<<"REPORTE DE REPARTIDORES"<<endl;
    for (int i = 0; strcmp(arrReps[i].codigo,"FIN")!=0; i++) {
        archRep<<arrReps[i];
    }
    return 0;
}

