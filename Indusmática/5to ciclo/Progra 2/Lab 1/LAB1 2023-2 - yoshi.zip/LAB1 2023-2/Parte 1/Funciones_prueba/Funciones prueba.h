/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Funciones prueba.h
 * Author: Usuario
 *
 * Created on 10 de abril de 2025, 22:43
 */

#ifndef FUNCIONES_PRUEBA_H
#define FUNCIONES_PRUEBA_H

void leer(const char* nomArch, struct Cliente *arrClientes);
void leer(const char* nomArch, struct Producto *arrProd);
void leer(const char* nomArch, struct Cliente *arrClientes, struct Producto *arrProd);
void imprimir(const struct Cliente *arrClientes, const struct Producto *arrProd,
        const char* nomArch);

bool operator >>(ifstream &arch, struct Cliente &cliente);
bool operator >>(ifstream &arch, struct Producto &producto);
bool operator >>(ifstream &arch, struct Pedido &pedido);
void operator +=(struct Cliente *arrClientes, struct Pedido pedido);
bool operator +=(struct Producto *arrProductos, struct Pedido &pedido);
void operator <<(ofstream &arch, struct Cliente cliente);
void operator <<(ofstream &arch, struct Producto producto);

#endif /* FUNCIONES_PRUEBA_H */

