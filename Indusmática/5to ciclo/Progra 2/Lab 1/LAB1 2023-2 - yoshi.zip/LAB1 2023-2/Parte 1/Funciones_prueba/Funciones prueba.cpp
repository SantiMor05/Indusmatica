/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Estructuras.h"
#include "Funciones prueba.h"

void leer(const char* nomArch, struct Cliente *arrClientes){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    int i=0;
    while(archLee>>arrClientes[i]) i++;
    arrClientes[i].dni = 0;
}

void leer(const char* nomArch, struct Producto *arrProd){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    int i=0;
    while(archLee>>arrProd[i]) i++;
    strcpy(arrProd[i].codigo,"XXXXXXX");
}

void leer(const char* nomArch, struct Cliente *arrClientes, struct Producto *arrProd){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    struct Pedido pedido;
    while(archLee>>pedido){
        arrClientes += pedido;
        arrProd += pedido;
    }
}


bool operator >>(ifstream &arch, struct Cliente &cliente){
        arch>>cliente.dni;
        if (arch.eof()) return false;
        arch.get();
        arch.getline(cliente.nombre,100,',');
        arch>>cliente.telefono;
        cliente.cantidadProductosEntrgados = 0;
        cliente.montoTotal = 0;
        return true;
}

bool operator >>(ifstream &arch, struct Producto &producto){
    arch.getline(producto.codigo,8,',');
    if (arch.eof()) return false;
    arch.getline(producto.descripcion,60,',');
    arch>>producto.precio;
    arch.get();
    arch>>producto.stock;
    arch.get();
    return true;
}

bool operator >>(ifstream &arch, struct Pedido &pedido){
    arch.getline(pedido.CodigoProducto,8,',');
    if (arch.eof()) return false;
    arch>>pedido.dniCliente;
    arch.get();
    return true;
}

void operator +=(struct Cliente *arrClientes, struct Pedido pedido){
    int np;
    for (int i = 0; arrClientes[i].dni; i++)
        if (pedido.dniCliente==arrClientes[i].dni){
            np = arrClientes[i].cantidadProductosEntrgados;
            arrClientes[i].productosEntregados[np].precio = pedido.precioProducto;
            strcpy(arrClientes[i].productosEntregados[np].codigo,pedido.CodigoProducto);
            arrClientes[i].cantidadProductosEntrgados++;
            arrClientes[i].montoTotal += pedido.precioProducto;
        }
}

bool operator +=(struct Producto *arrProductos, struct Pedido &pedido){
    int nc;
    for (int i = 0; strcmp(arrProductos[i].codigo,"XXXXXXX")!=0; i++)
        if (strcmp(pedido.CodigoProducto,arrProductos[i].codigo)==0){
            pedido.precioProducto = arrProductos[i].precio;
            if (arrProductos[i].stock>0){
                nc = arrProductos[i].cantidadClientesServidos;
                arrProductos[i].clientesServidos[nc] = pedido.dniCliente;
                arrProductos[i].cantidadClientesServidos++;
                arrProductos[i].stock--;
                return true;
            }else{
                nc = arrProductos[i].cantidadClientesNoServidos;
                arrProductos[i].clientesNoServidos[nc] = pedido.dniCliente;
                arrProductos[i].cantidadClientesNoServidos++;
                return false;
            }
        }
}

void operator <<(ofstream &arch, struct Cliente cliente){
    arch.precision(2);
    arch<<fixed;
    arch<<cliente.dni<<"   "<<left<<setw(60)<<cliente.nombre<<right<<setw(12)<<
            cliente.telefono<<setw(10)<<cliente.montoTotal<<endl;
    arch<<"Productos entregados:"<<endl;
    for (int i = 0; i < cliente.cantidadProductosEntrgados; i++) {
        arch<<setw(12)<<cliente.productosEntregados[i].codigo<<endl;
    }
    if(cliente.cantidadProductosEntrgados==0) arch<<"NO SE ENTREGARON PRODUCTOS"<<endl;
}

void operator <<(ofstream &arch, struct Producto producto){
    arch<<producto.codigo<<left<<"   "<<setw(65)<<producto.descripcion<<right<<
            setw(10)<<producto.precio<<setw(5)<<producto.stock<<endl;
    arch<<"Clientes atendidos: ";
    for (int i = 0; i < producto.cantidadClientesServidos; i++) 
        arch<<producto.clientesServidos[i]<<"   ";
    if (producto.cantidadClientesServidos==0) arch<<"NO SE ATENDIERON PEDIDOS";
    arch<<endl;
    arch<<"Clientes no atendidos: ";
    for (int i = 0; i < producto.cantidadClientesNoServidos; i++)
        arch<<producto.clientesNoServidos[i]<<"   ";
    if (producto.cantidadClientesNoServidos==0) arch<<"NO HAY CLIENTES SIN ATENDER";
    arch<<endl;
}

void imprimir(const struct Cliente *arrClientes, const struct Producto *arrProd,
        const char* nomArch){
    ofstream archRep(nomArch,ios::out);
    if (not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    archRep<<"REPORTE DE CLIENTES"<<endl;
    for (int i = 0; arrClientes[i].dni; i++)
        archRep<<arrClientes[i];
    archRep<<endl<<"REPORTE DE PRODUCTOS"<<endl;
    for (int i = 0; strcmp(arrProd[i].codigo,"XXXXXXX")!=0; i++)
        archRep<<arrProd[i];
}