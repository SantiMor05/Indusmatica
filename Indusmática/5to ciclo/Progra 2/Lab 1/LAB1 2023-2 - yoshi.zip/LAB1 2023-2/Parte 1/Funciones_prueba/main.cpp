/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 10 de abril de 2025, 22:43
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "Estructuras.h"
#include "Funciones prueba.h"

int main(int argc, char** argv) {
    struct Cliente arrClientes[18]{};
    struct Producto arrProd[35]{};
    leer("ClientesPrueba.csv",arrClientes);
    leer("ProductosPrueba.csv",arrProd);
    leer("PedidosPrueba.csv", arrClientes, arrProd);
    imprimir(arrClientes, arrProd,"Prueba.txt");
    return 0;
}

