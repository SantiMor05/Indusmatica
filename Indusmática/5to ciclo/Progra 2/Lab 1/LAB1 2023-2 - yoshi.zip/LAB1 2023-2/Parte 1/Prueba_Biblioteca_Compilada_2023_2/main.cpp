/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 11 de abril de 2025, 00:01
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Estructuras.h"
#include "Funciones prueba.h"

void leer(const char* nomArch, struct Cliente *arrClientes){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    int i=0;
    while(archLee>>arrClientes[i]) i++;
    arrClientes[i].dni = 0;
}

void leer(const char* nomArch, struct Producto *arrProd){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    int i=0;
    while(archLee>>arrProd[i]) i++;
    strcpy(arrProd[i].codigo,"XXXXXXX");
}

void leer(const char* nomArch, struct Cliente *arrClientes, struct Producto *arrProd){
    ifstream archLee(nomArch,ios::in);
    if (not archLee.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    struct Pedido pedido;
    while(archLee>>pedido){
        arrClientes += pedido;
        arrProd += pedido;
    }
}

void imprimir(const struct Cliente *arrClientes, const struct Producto *arrProd,
        const char* nomArch){
    ofstream archRep(nomArch,ios::out);
    if (not archRep.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nomArch<<endl;
        exit(1);
    }
    archRep<<"REPORTE DE CLIENTES"<<endl;
    for (int i = 0; arrClientes[i].dni; i++)
        archRep<<arrClientes[i];
    archRep<<endl<<"REPORTE DE PRODUCTOS"<<endl;
    for (int i = 0; strcmp(arrProd[i].codigo,"XXXXXXX")!=0; i++)
        archRep<<arrProd[i];
}



int main(int argc, char** argv) {
    struct Cliente arrClientes[18]{};
    struct Producto arrProd[35]{};
    leer("ClientesPrueba.csv",arrClientes);
    leer("ProductosPrueba.csv",arrProd);
    leer("PedidosPrueba.csv", arrClientes, arrProd);
    imprimir(arrClientes, arrProd,"Prueba.txt");
    return 0;
}

