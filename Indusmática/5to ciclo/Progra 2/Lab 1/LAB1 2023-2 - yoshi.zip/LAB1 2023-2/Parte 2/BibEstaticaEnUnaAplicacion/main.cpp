/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 11 de abril de 2025, 00:10
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "Estructuras.h"
#include "AperturaDeArchivos.h"
#include "Funciones prueba.h"

/*
 * 
 */
int main(int argc, char** argv) {
    struct Cliente arrClientes[150]{};
    struct Producto arrProd[170]{};
    ifstream archCL, archPR, archPD; 
    ofstream archRep;
    AperturaDeUnArchivoDeTextosParaLeer(archCL,"Clientes.csv");
    int i=0;
    while(archCL>>arrClientes[i]) i++;
    arrClientes[i].dni = 0;
    AperturaDeUnArchivoDeTextosParaLeer(archPR,"Productos.csv");
    i=0;
    while(archPR>>arrProd[i]) i++;
    strcpy(arrProd[i].codigo,"XXXXXXX");
    AperturaDeUnArchivoDeTextosParaLeer(archPD,"Pedidos.csv");
    struct Pedido pedido;
    while(archPD>>pedido){
        arrClientes += pedido;
        arrProd += pedido;
    }
    AperturaDeUnArchivoDeTextosParaEscribir(archRep,"Reporte.txt");
    archRep<<"REPORTE DE CLIENTES"<<endl;
    for (int i = 0; arrClientes[i].dni; i++)
        archRep<<arrClientes[i];
    archRep<<endl<<"REPORTE DE PRODUCTOS"<<endl;
    for (int i = 0; strcmp(arrProd[i].codigo,"XXXXXXX")!=0; i++)
        archRep<<arrProd[i];
    return 0;
}

