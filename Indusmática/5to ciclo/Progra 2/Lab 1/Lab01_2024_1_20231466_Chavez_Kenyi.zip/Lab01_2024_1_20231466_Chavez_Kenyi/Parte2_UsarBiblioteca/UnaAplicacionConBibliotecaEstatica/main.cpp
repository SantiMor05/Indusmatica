/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: kenyi
 *
 * Created on 10 de abril de 2025, 05:02 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "OperadoresSobreCargados.h"
#include "FuncionesAuxiliares.h"
/*
 * 
 */
int main(int argc, char** argv) {

    struct Libro arrLibro[300]{};
    struct Cliente arrClinte[300]{};
    
    leerLibro(arrLibro,"Libros.csv");
    
    leerClientes(arrClinte,"Clientes.csv");
    
    leerPedidos(arrLibro,arrClinte,"Pedidos.txt");
    
    emitirReporte(arrLibro,arrClinte,"Reporte.txt");
    return 0;
}

