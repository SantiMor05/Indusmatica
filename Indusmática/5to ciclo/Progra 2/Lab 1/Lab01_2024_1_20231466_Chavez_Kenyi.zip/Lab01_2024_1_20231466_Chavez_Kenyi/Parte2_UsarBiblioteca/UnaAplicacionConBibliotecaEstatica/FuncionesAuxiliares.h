/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   FuncionesAuxiliares.h
 * Author: kenyi
 *
 * Created on 10 de abril de 2025, 05:09 PM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

void leerLibro(struct Libro *arrLibro, const char *arch);

void leerClientes(struct Cliente *arrCliente, const char *arch);

void leerPedidos(struct Libro *arrLibro, struct Cliente *arrCliente,
        const char *arch);

int buscarCliente(struct Cliente *arrCliente,int dni);

void imprimirLinea(int n,char c,ofstream &arch);

void emitirReporte(struct Libro *arrLibro, struct Cliente *arrCliente,
        const char *arch);

#endif /* FUNCIONESAUXILIARES_H */
