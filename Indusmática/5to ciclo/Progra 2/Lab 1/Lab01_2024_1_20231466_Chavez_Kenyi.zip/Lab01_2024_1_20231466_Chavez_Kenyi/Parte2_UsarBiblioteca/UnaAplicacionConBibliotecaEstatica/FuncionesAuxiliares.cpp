/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   FuncionesAuxiliares.cpp
 * Author: kenyi
 * 
 * Created on 10 de abril de 2025, 05:09 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;
#include "AperturaDeArchivos.h"
#include "OperadoresSobreCargados.h"
#include "FuncionesAuxiliares.h"
#include "Estructuras.h"
#define NO_ENCONTRADO -1

void leerLibro(struct Libro *arrLibro, const char *arch) {
    ifstream archLib;

    AperturaDeUnArchivoDeTextosParaLeer(archLib, arch);

    int i = 0;
    while (true) {
        if (!(archLib >> arrLibro[i])) {
            strcpy(arrLibro[i].codigo, "FIN");
            break;
        }
        i++;
    }

}

void leerClientes(struct Cliente *arrCliente, const char *arch) {
    ifstream archCli;
    AperturaDeUnArchivoDeTextosParaLeer(archCli, arch);

    int i = 0;
    while (true) {
        if (!(archCli >> arrCliente[i])) {
            arrCliente[i].dni = 0;
            break;
        }
        i++;
    }
}

void leerPedidos(struct Libro *arrLibro, struct Cliente *arrCliente,
        const char *arch) {
    ifstream archPed;
    AperturaDeUnArchivoDeTextosParaLeer(archPed, arch);

    struct LibroSolicitado pedido;

    int numPedido, dni, pos;
    char codigo[8];

    while (true) {
        archPed>>numPedido;
        if (archPed.eof())break;
        pedido.numeroDePedido = numPedido;
        archPed.get();
        archPed>>dni;
        archPed.get();
        while (archPed.get() != '\n') {
            archPed>>codigo;
            strcpy(pedido.codigoDelLibro, codigo);
            pedido>>arrLibro;
            pos = buscarCliente(arrCliente, dni);
            if (pos != NO_ENCONTRADO) {
                arrCliente[pos] << pedido;
            }
        }
    }
    for (int i = 0; arrCliente[i].dni != 0; i++)
        ++arrCliente[i];


}

int buscarCliente(struct Cliente *arrCliente, int dni) {
    for (int i = 0; arrCliente[i].dni != 0; i++) {
        if (arrCliente[i].dni == dni)return i;
    }
    return NO_ENCONTRADO;
}

void emitirReporte(struct Libro *arrLibro, struct Cliente *arrCliente,
        const char *arch) {
    ofstream archRep;

    AperturaDeUnArchivoDeTextosParaEscribir(archRep, arch);
    archRep << "CODIGO" << "    " << "NOMBRE" << endl;
    imprimirLinea(40, '-', archRep);
    for (int i = 0; strcmp(arrLibro[i].codigo, "FIN") != 0; i++)
        archRep << arrLibro[i];
    imprimirLinea(40, '=', archRep);
    for (int i = 0; arrCliente[i].dni != 0; i++) {
        archRep << "N° DNI" << "   " << "NOMBRE" << endl;
        imprimirLinea(40, '-', archRep);
        archRep << arrCliente[i];
        imprimirLinea(40, '-', archRep);
    }
}

void imprimirLinea(int n, char c, ofstream &arch) {
    for (int i = 0; i < n; i++)arch.put(c);
    arch << endl;
}