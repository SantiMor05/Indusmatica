/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   OperadoresSobreCargados.h
 * Author: kenyi
 *
 * Created on 10 de abril de 2025, 01:38 PM
 */

#ifndef OPERADORESSOBRECARGADOS_H
#define OPERADORESSOBRECARGADOS_H
//Lectura
bool operator>>(ifstream &archLib, struct Libro &libro);
bool operator>>(ifstream &archCli, struct Cliente &cliente);
//Operaciones
bool operator>>(struct LibroSolicitado &libroPedido, struct Libro *arrLibro);
bool operator<<(struct Cliente &cliente, struct LibroSolicitado &pedido);
void operator++(struct Cliente &cliente);
//Impresion
void operator<<(ofstream &archLib, const struct Libro libro);
void operator<<(ofstream &archCli, const struct Cliente cliente);
#endif /* OPERADORESSOBRECARGADOS_H */