/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   OperadoresSobreCargados.cpp
 * Author: kenyi
 * 
 * Created on 10 de abril de 2025, 01:38 PM
 */
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;
#include "OperadoresSobreCargados.h"
#include "Estructuras.h"

//Lectura
//IIM5175,Diamantes y pedernales,Jose Maria Arguedas,2,30.23
//YDK7687,El otonio del patriarca,Gabriel Garcia Marquez,60,82.02

bool operator>>(ifstream &archLib, struct Libro &libro) {
    archLib.getline(libro.codigo, 8, ',');
    if (archLib.eof())return false;
    archLib.getline(libro.tiltulo, 80, ',');
    archLib.getline(libro.autor, 60, ',');
    archLib >> libro.stock;
    archLib.get();
    archLib >> libro.precio;
    archLib.get();
    return true;
}

//54393647,Reyes Tang Edward 

bool operator>>(ifstream &archCli, struct Cliente &cliente) {
    archCli >> cliente.dni;
    if (archCli.eof())return false;
    archCli.get();
    archCli.getline(cliente.nombre, 60);
    cliente.cantDeLibros = 0;
    cliente.pagoTotal = 0;
    return true;
}

//Operaciones

bool operator>>(struct LibroSolicitado &libroPedido, struct Libro *arrLibro) {
    for (int i = 0; strcmp(arrLibro[i].codigo, "FIN") != 0; i++) {
        if (strcmp(libroPedido.codigoDelLibro, arrLibro[i].codigo) == 0) {
            if (arrLibro[i].stock > 0) {
                arrLibro[i].stock--;
                libroPedido.precio = arrLibro[i].precio;
                libroPedido.atendido = true;
                return true;
            } else {
                libroPedido.atendido = false;
                return false;
            }
        }
    }
    return false;
}

bool operator<<(struct Cliente &cliente, struct LibroSolicitado &pedido) {
    int cant;
    if (cliente.cantDeLibros < 30) {
        cant = cliente.cantDeLibros;
        cliente.librosSolicitados[cant] = pedido;
        cliente.cantDeLibros++;
        return true;
    } else return false;
}

void operator++(struct Cliente &cliente) {
    int cant = cliente.cantDeLibros;
    for (int i = 0; i < cant; i++) {
        cliente.pagoTotal += cliente.librosSolicitados[i].precio;
    }
}

void operator<<(ofstream &archLib, const struct Libro libro) {
    archLib.precision(2);
    archLib << fixed;
    archLib << left << setw(10) << libro.codigo << setw(80) <<
            libro.tiltulo << right << setw(8) << libro.stock <<
            setw(10) << libro.precio << endl;
}

void operator<<(ofstream &archCli, const struct Cliente cliente) {
    archCli.precision(2);
    archCli << fixed;
    archCli << left << setw(10) << cliente.dni << cliente.nombre <<
            right << endl << "Libros entregados:" << endl;
    archCli << setw(20) << "Pedido No." << setw(10) << "Codigo" << setw(12)
            << "Precio" << endl;
    for (int i = 0; i < cliente.cantDeLibros; i++) {
        if (cliente.librosSolicitados[i].atendido) {
            archCli << setw(12) << " " << setw(5) << setfill('0')
                    << cliente.librosSolicitados[i].numeroDePedido << setfill(' ')
                    << setw(12) << cliente.librosSolicitados[i].codigoDelLibro
                    << setw(10) << cliente.librosSolicitados[i].precio << endl;
        }
    }
    archCli << "Total a pagar: " << cliente.pagoTotal << endl;
    archCli << "Libros no entregados por falta de stock: " << endl <<
            setw(20) << "Pedido No." << setw(10) << "Codigo" << endl;
    for (int i = 0; i < cliente.cantDeLibros; i++) {
        if (!cliente.librosSolicitados[i].atendido) {
            archCli << setw(12) << " " << setw(4) << setfill('0')
                    << cliente.librosSolicitados[i].numeroDePedido << setfill(' ')
                    << setw(12) << cliente.librosSolicitados[i].codigoDelLibro
                    << endl;
        }
    }
}
