/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: kenyi
 *
 * Created on 10 de abril de 2025, 04:56 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#include "AperturaDeArchivos.h"
#include "Estructuras.h"
#include "OperadoresSobreCargados.h"

/*
 * 
 */
int main(int argc, char** argv) {

    ifstream archLib, archPed, archCli;
    ofstream archRepLib, archRepCli;

    AperturaDeUnArchivoDeTextosParaLeer(archLib
            , "Libros.csv");
    AperturaDeUnArchivoDeTextosParaLeer(archCli
            , "Cientes.csv");
    AperturaDeUnArchivoDeTextosParaLeer(archPed
            , "Pedidos.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(archRepCli,
            "ReporteCliente.txt");
    AperturaDeUnArchivoDeTextosParaEscribir(archRepLib,
            "ReporteLibro.txt");

    struct Cliente arrCliente[300]{}, cli;
    struct Libro arrLibro[300]{}, lib;
    struct LibroSolicitado pedido;


    int i = 0;
    while (true) {
        if (!(archLib >> arrLibro[i])) {
            strcpy(arrLibro[i].codigo, "FIN");
            break;
        }
        i++;
    }

    i = 0;
    while (true) {
        if (!(archCli >> cli)) {
            arrCliente[i].dni = 0;
            break;
        }
        arrCliente[i] = cli;
        i++;
    }

    int numPedido, dni;
    char codigo[8];

    while (true) {
        archPed>>numPedido;
        if (archPed.eof())break;
        pedido.numeroDePedido = numPedido;
        archPed.get();
        archPed>>dni;
        archPed.get();
        while (archPed.get() != '\n') {
            archPed>>codigo;
            strcpy(pedido.codigoDelLibro, codigo);
            pedido>>arrLibro;
            for (int i = 0; arrCliente[i].dni != 0; i++)
                if (arrCliente[i].dni == dni) {
                    arrCliente[i] << pedido;
                    break;
                }
        }
    }
    for (int i = 0; arrCliente[i].dni != 0; i++)
        ++arrCliente[i];

    for (int i = 0; strcmp(arrLibro[i].codigo, "FIN") != 0; i++)
        archRepLib << arrLibro[i];

    for (int i = 0; arrCliente[i].dni != 0; i++)
        archRepCli << arrCliente[i];
    return 0;
}

