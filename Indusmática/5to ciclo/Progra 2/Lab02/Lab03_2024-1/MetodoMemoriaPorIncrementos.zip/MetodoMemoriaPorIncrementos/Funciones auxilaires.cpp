/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones auxilaires.cpp
 * Author: alulab14
 * 
 * Created on 24 de abril de 2025, 06:05 PM
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Funciones auxilaires.h"
#define INCREMENTO 5

void lecturaDelibros(char ***&libros, int **&stock,const char* nomArch){
    ifstream arch;
    AperturaDeUnArchivoDeTextosParaLeer(arch,nomArch);
    char *codigo, *nombre, *autor;
    int sto, numDat=0, cap=0;
    while(true){
        codigo = leer_cadena(arch);
        if (arch.eof()) break;
        nombre = leer_cadena(arch);
        autor = leer_cadena(arch);
        arch>>sto;
        while(arch.get()!='\n');
        if(numDat==cap) incrementar_espacios(libros,stock,numDat,cap);
        ingresar_datos(codigo,nombre,autor,sto,libros[numDat-1],stock[numDat-1]);
        numDat++;
    }
}

char *leer_cadena(ifstream &arch){
    char *cad, buffer[100];
    arch.getline(buffer,100,',');
    if (arch.eof()) return nullptr;
    cad = new char[strlen(buffer)+1]{};
    strcpy(cad,buffer);
    return cad;
}

void incrementar_espacios(char ***&libros, int **&stock, int &numDat, int &cap){
    cap += INCREMENTO;
    if (numDat==0){
        libros = new char**[cap]{};
        stock = new int*[cap]{};
        numDat = 1;
    }else{
        char ***buffLibros = new char**[cap]{};
        int **buffStock = new int*[cap]{};
        for (int i = 0; i < numDat; i++) {
            buffLibros[i] = libros[i];
            buffStock[i] = stock[i];
        }
        delete libros;
        delete stock;
        libros = buffLibros;
        stock = buffStock;
    }
}

void ingresar_datos(char *codigo, char *nombre,char *autor,int sto,char **&libros,int *&stock){
    libros = new char*[3];
    stock = new int[2];
    libros[0] = codigo;
    libros[1] = nombre;
    libros[2] = autor;
    stock[0] = sto;
    stock[1] = 0;
}

void prubeaLecturasPedidos(char ***libros, int **stock,const char* nomArch){
    ofstream arch;
    AperturaDeUnArchivoDeTextosParaEscribir(arch,nomArch);
    arch<<"CODIGO"<<setw(20)<<"NOMBRE"<<setw(40)<<"AUTOR"<<setw(10)<<"STOCK1"<<
            setw(10)<<"SOTCK2"<<endl;
    char **libro;
    int* stocki;
    for (int i = 0; libros[i]; i++) {
        libro = libros[i];
        stocki = stock[i];
        arch<<libro[0]<<setw(60)<<libro[1]<<setw(30)<<libro[2]<<setw(8)<<stocki[0]
                <<setw(8)<<stocki[1]<<endl;
    }
}

void atencionPedidos(const char*nomArch, char ***libros, int **stock,
        int **&pedidosClientes,char ***&pedidosLibros,bool **&pedidosAtendidos){
    ifstream arch;
    AperturaDeUnArchivoDeTextosParaLeer(arch,nomArch);
    int numPedido, dni, cap=0;
    char codLib[8];
    pedidosAtendidos = nullptr;
    while(true){
        arch>>numPedido;
        if (arch.eof()) break;
        arch.get();
        arch>>dni;
        if (numPedido>=cap) incrementar_espacios(numPedido,cap,pedidosAtendidos,pedidosClientes,
                pedidosLibros);
        
        while(true){
            if (arch.get()=='\n') break;
            arch>>codLib;
            
        }
    }
}

void incrementar_espacios(int numPedido, int &cap, bool**&pedidosAtendidos,
        int **&pedidosClientes, char ***&pedidosLibros){
    cap += INCREMENTO + numPedido;
    if (pedidosAtendidos == nullptr){
        pedidosAtendidos = new bool*[cap]{};
        pedidosClientes = new int*[cap]{};
        pedidosLibros = new char**[cap]{};
    }else{
        bool **buffPedidosAtendidos = new bool*[cap]{};
        int **buffPedidosClientes = new int*[cap]{};
        char ***buffPedidosLibros = new char**[cap]{};
        for (int i = 0; i < numPedido+1; i++) {
            buffPedidosAtendidos[i] = pedidosAtendidos[i];
            buffPedidosClientes[i] = pedidosClientes[i];
            buffPedidosLibros[i] = pedidosLibros[i];
        }
        delete pedidosAtendidos;
        delete pedidosClientes;
        delete pedidosLibros;
        pedidosAtendidos = buffPedidosAtendidos;
        pedidosClientes = buffPedidosClientes;
        pedidosLibros = buffPedidosLibros;
    }
}