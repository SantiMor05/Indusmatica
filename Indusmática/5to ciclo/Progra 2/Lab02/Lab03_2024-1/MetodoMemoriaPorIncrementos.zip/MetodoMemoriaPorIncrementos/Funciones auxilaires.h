/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Funciones auxilaires.h
 * Author: alulab14
 *
 * Created on 24 de abril de 2025, 06:05 PM
 */

#ifndef FUNCIONES_AUXILAIRES_H
#define FUNCIONES_AUXILAIRES_H

void lecturaDelibros(char ***&libros, int **&stock,const char* nomArch);
char *leer_cadena(ifstream &arch);
void incrementar_espacios(char ***&libros, int **&stock, int &numDat, int &cap);
void ingresar_datos(char *codigo, char *nombre,char *autor,int sto,char **&libros,int *&stock);
void prubeaLecturasPedidos(char ***libros, int **stock,const char* nomArch);
void atencionPedidos(const char*nomArch, char ***libros, int **stock,
        int **&pedidosClientes,char ***&pedidosLibros,bool **&pedidosAtendidos);
void incrementar_espacios(int numPedido, int &cap, bool**&pedidosAtendidos,
        int **&pedidosClientes, char ***&pedidosLibros);

#endif /* FUNCIONES_AUXILAIRES_H */
