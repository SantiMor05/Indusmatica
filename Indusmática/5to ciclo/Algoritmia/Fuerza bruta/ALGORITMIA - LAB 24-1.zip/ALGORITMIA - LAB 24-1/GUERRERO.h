/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   GUERRERO.h
 * Author: Usuario
 *
 * Created on 3 de abril de 2025, 09:46
 */

#ifndef GUERRERO_H
#define GUERRERO_H


struct Guerrero{
    int poder;
    int tipo_matar[3];
};

#endif /* GUERRERO_H */

