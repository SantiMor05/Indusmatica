/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 3 de abril de 2025, 09:35
 */

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

#include "ARMAS.h"
#include "GUERRERO.h"

void armas(struct Arma * arrARMAS){
    arrARMAS[0].nombre = 'Z'; arrARMAS[0].poder = 60; arrARMAS[0].tipo = 3; 
    arrARMAS[1].nombre = 'P'; arrARMAS[1].poder = 80; arrARMAS[1].tipo = 1; 
    arrARMAS[2].nombre = 'R'; arrARMAS[2].poder = 38; arrARMAS[2].tipo = 2;
    arrARMAS[3].nombre = 'D'; arrARMAS[3].poder = 25; arrARMAS[3].tipo = 2;
    arrARMAS[4].nombre = 'E'; arrARMAS[4].poder = 49; arrARMAS[4].tipo = 2;
    arrARMAS[5].nombre = 'F'; arrARMAS[5].poder = 57; arrARMAS[5].tipo = 1;
    arrARMAS[6].nombre = 'G'; arrARMAS[6].poder = 68; arrARMAS[6].tipo = 3;
    arrARMAS[7].nombre = 'H'; arrARMAS[7].poder = 35; arrARMAS[7].tipo = 2;
    arrARMAS[8].nombre = 'I'; arrARMAS[8].poder = 62; arrARMAS[8].tipo = 2;
    arrARMAS[9].nombre = 'J'; arrARMAS[9].poder = 42; arrARMAS[9].tipo = 2;
    arrARMAS[10].nombre = 'K'; arrARMAS[10].poder = 36; arrARMAS[10].tipo = 1;
    arrARMAS[11].nombre = 'L'; arrARMAS[11].poder = 54; arrARMAS[11].tipo = 3;
    
    arrARMAS[1].prerequisitos[0] = 'Z';
    arrARMAS[3].prerequisitos[0] = 'R';
    arrARMAS[7].prerequisitos[0] = 'Z'; arrARMAS[7].prerequisitos[1] = 'E';
    arrARMAS[8].prerequisitos[0] = 'R';
    arrARMAS[10].prerequisitos[0] = 'Z';
}

guerreros(struct Guerrero *arrGUERREROS){
    arrGUERREROS[0].poder = 120; arrGUERREROS[0].tipo_matar[0] = 2; 
    arrGUERREROS[1].poder = 160; arrGUERREROS[1].tipo_matar[0] = 1; arrGUERREROS[1].tipo_matar[1] = 3; 
    arrGUERREROS[2].poder = 80; arrGUERREROS[2].tipo_matar[0] = 3; 
}

cargabin(int num, int base, int *cromo, int n){
    int res, i=0;
    for (int j = 0; j < n; j++) cromo[j] = 0;
    while(num>0){
        res = num % base;
        num /= base;
        cromo[i] = res;
        i++;
    }
}

bool validar_arma(int *cromo, const struct Arma *auxARMAS, const struct Guerrero *auxGUERREROS, 
        int i, int numGuerrero){
    for (int m = 0; m < 3; m++) {
        if (auxGUERREROS[numGuerrero].tipo_matar[m]==auxARMAS[i].tipo and cromo[i]==numGuerrero+1){
            int numReq=0;
            for (int v = 0; v < 3; v++) {
                if (auxARMAS[i].prerequisitos[v]==0) numReq++;
                else{
                    for (int q = 0; q < 12; q++) {
                        if (cromo[i]==cromo[q]  and i!=q){
                            if (auxARMAS[i].prerequisitos[v]==auxARMAS[q].nombre)
                                numReq++;
                        }
                    }
                }
            }
            if (numReq==3) return true;
        }
    }
    return false;
}

bool evaluar_guerrero(int *cromo, const struct Arma *auxARMAS, const struct Guerrero *auxGUERREROS, 
        int n, int numGuerrero){
    int sumaPoder=0;
    for (int i = 0; i < n; i++) {
        if (validar_arma(cromo, auxARMAS, auxGUERREROS, i, numGuerrero))
            sumaPoder += auxARMAS[i].poder;
    }
    if (sumaPoder>auxGUERREROS[numGuerrero].poder) return true;
    return false;
}

bool evaluar_cromo(int *cromo, const struct Arma *auxARMAS, const struct Guerrero *auxGUERREROS, int n){
    bool guerr1Vencido, guerr2Vencido, guerr3Vencido;
    guerr1Vencido = evaluar_guerrero(cromo,auxARMAS,auxGUERREROS,n,0);
    guerr2Vencido = evaluar_guerrero(cromo,auxARMAS,auxGUERREROS,n,1);
    guerr3Vencido = evaluar_guerrero(cromo,auxARMAS,auxGUERREROS,n,2);
    if (guerr1Vencido and guerr2Vencido and guerr3Vencido) return true;
    return false;
}

int main(int argc, char** argv) {
    struct Arma arrARMAS[12]{}, auxARMAS[12]{};
    struct Guerrero arrGUERREROS[3]{}, auxGUERREROS[3]{};
    int numProb = (int)pow(4,12), n=12;
    int cromo[n];
    bool opcion;
    int num=0;
    armas(auxARMAS);
    guerreros(auxGUERREROS);
    for (int i = 0; i < numProb; i++) {
        cargabin(i,4,cromo,n);
        opcion = evaluar_cromo(cromo,auxARMAS,auxGUERREROS,n);
        if (opcion){
            cout<<"EXITE UNA SOLUCION: ";
            for (int i = 0; i < 12; i++) {
                if (cromo[i]>0){
                    cout<<auxARMAS[i].nombre<<"|"<<cromo[i]<<"  ";
                    num++;
                }
            }
            cout<<endl;
        }
    }
    cout<<"Hay "<<num<<"soluciones";
    return 0;
}

