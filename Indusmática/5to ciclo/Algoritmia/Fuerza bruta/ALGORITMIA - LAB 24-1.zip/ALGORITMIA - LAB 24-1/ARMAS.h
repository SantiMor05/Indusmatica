/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   ARMAS.h
 * Author: Usuario
 *
 * Created on 3 de abril de 2025, 09:45
 */

#ifndef ARMAS_H
#define ARMAS_H


struct Arma{
    char nombre;
    int poder;
    int tipo;
    char prerequisitos[3];
};

#endif /* ARMAS_H */

