/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 4 de abril de 2025, 17:10
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <cmath>
#define N 4
using namespace std;


void cargabin(int num,int base, int cromo[N][N], int n){
    int res, i=0, j=0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) cromo[i][j]=0; 
    while(num>0){
        res = num % base;
        num /= base;
        if (j>3){
            j = 0;
            i++;
        }
        cromo[i][j] = res;
        j++;
    }
}

void evaluar_Cromo(int cromo[N][N], int pesos[][N], int valores[][N], int &besti, 
        int &Gmax, int Pmax, int num){
    int ganancia=0, suma=0;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            suma += cromo[i][j] * pesos[i][j];
            ganancia += cromo[i][j] * valores[i][j];
        }
    }
    if (suma<=Pmax){
        if (ganancia>Gmax){
            Gmax = ganancia;
            besti = num;
        }
    }
}

//////////////////////////////////////////////////////////////////////////////

void movimientos(int mov[8][2]){
    mov[0][0] = -1; mov[0][1] = 0;
    mov[1][0] = -1; mov[1][1] = 1;
    mov[2][0] = 0; mov[2][1] = 1;
    mov[3][0] = 1; mov[3][1] = 1;
    mov[4][0] = 1; mov[4][1] = 0;
    mov[5][0] = 1; mov[5][1] = -1;
    mov[6][0] = 0; mov[6][1] = -1;
    mov[7][0] = -1; mov[7][1] = -1;
}

bool buscar_palabra(char tabla[4][10],int mov[8][2], int x, int y, char palabra[3]){
    int i,v,q;
    for (v = 0; v < 3; v++) {
        if (palabra[v]==tabla[x][y]){
            for (i = 0; i < 8; i++) {
                int nx = x + mov[i][0];
                int ny = y + mov[i][1];
                    if (nx>=0 and ny>=0 and nx<4 and ny<10){
                        for (int p = 0; p < 3; p++) {
                            if (p!=v and palabra[p]==tabla[nx][ny]){
                                nx += + mov[i][0];
                                ny += + mov[i][1];
                                if (nx>=0 and ny>=0 and nx<4 and ny<10)
                                    for (int f = 0; f < 3; f++) {
                                        if (f!=v and f!=p and palabra[f]==tabla[nx][ny])
                                            return true;
                                        }
                            }
                        }
                    }
                }

            }

        }
    return false;
}

int main(int argc, char** argv) {
    int Pmax = 100, besti, Gmax;
    int pesos[][N] = {      {20,20,20,20},
                            {10,30,10,30},
                            {10,10,10,10},
                            {15,15,15,15}};
    int valores[][N] = {    {10,10,10,50},
                            {80,10,10,20},
                            {20,20,20,20},
                            {50,50,50,50}};
    int opcion = (int)pow(2,16), cromo[4][4]{};
    for (int i = 0; i < opcion; i++) {
        cargabin(i,2,cromo,4);
        evaluar_Cromo(cromo,pesos,valores,besti,Gmax,Pmax,i);
    }
    cargabin(besti,2,cromo,4);
    cout<<"La mejor solución obtiene "<<Gmax<<endl;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout<<cromo[i][j]*pesos[i][j]<<"  ";
        }
        cout<<endl;
    }
    cout<<endl<<endl;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout<<cromo[i][j]*valores[i][j]<<"  ";
        }
        cout<<endl;
    }
    
//////////////////////////////////////////////////////////////////////////////
    int mov[8][2]{};
    char tabla[4][10] = {   {'H','C','H','B','Y','S','O','S','O','H'},
                            {'S','C','S','S','Y','Q','O','S','Z','K'},
                            {'O','P','N','Y','O','K','F','H','C','K'},
                            {'O','B','N','I','Y','S','P','O','O','K'}};
    bool opci;
    char palabra[3] = {'H','S','O'};
    movimientos(mov);
    cout<<endl<<endl;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 10; j++) {
            opci = buscar_palabra(tabla,mov,i,j,palabra);
            if (opci)
                cout<<"La palabra empieza en ("<<i<<","<<j<<")"<<endl;
        }
    return 0;
}

