/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 4 de abril de 2025, 23:00
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

void cargabin(int num, int cromo[8], int base, int n, int &cantUNOS){
    int res, j=0;
    cantUNOS=0;
    for (int i = 0; i < n; i++) cromo[i]=0;
    while(num>0){
        res = num % base;
        num /= base;
        cromo[j] = res;
        if (cromo[j]==1) cantUNOS++;
        j++;
    }
}

void probar_cromo(int cromo[8], int n, int tabla[8][2], int Presup,
        int &sumaPresup, int &sumaHerra){
    sumaHerra=0; 
    sumaPresup=0;
    for (int i = 0; i < n; i++) {
        sumaHerra += cromo[i]*tabla[i][1];
        sumaPresup += cromo[i]* tabla[i][0] *tabla[i][1];
    }
}

int main(int argc, char** argv) {
    int maxHerra = 10, MaxRenovar=4, Presup=19, besti;
    int tabla[8][2] = {     {4,3},
                            {5,2},
                            {4,1},
                            {2,1},
                            {6,3},
                            {3,3},
                            {4,2},
                            {1,4}};
    int cantUNOS, opcion = (int)pow(2,8), n=8;
    int cromo[8]{}, mejorTotal, mejorMonto, mejor=0, sumaPresup, sumaHerra;
    for (int i = 0; i < opcion; i++) {
        cargabin(i,cromo,2,n,cantUNOS);
        if (cantUNOS<=MaxRenovar){
            probar_cromo(cromo,n, tabla, Presup, sumaPresup, sumaHerra);
            if (sumaPresup<=Presup)
            if (sumaHerra>mejor){
                mejor = sumaHerra;
                besti = i;
                mejorTotal = sumaHerra;
                mejorMonto = sumaPresup;
                }
        }
    }
    cargabin(besti,cromo,2,n,cantUNOS);
    cout<<"La mejor solución es: "<<endl;
    for (int i = 0; i < 8; i++) {
        if (cromo[i]!=0) cout<<i+1<<"  ";
    }
    cout<<endl;
    cout<<"Monto Total = "<<mejorMonto<<endl;
    cout<<"Cantidad de herramientas = "<<mejorTotal<<endl;
    return 0;
}

