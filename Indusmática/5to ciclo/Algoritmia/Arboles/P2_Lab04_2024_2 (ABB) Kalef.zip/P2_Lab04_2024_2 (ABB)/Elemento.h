/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Elemento.h
 * Author: GINITA
 *
 * Created on 28 de junio de 2025, 10:21 PM
 */

#ifndef ELEMENTO_H
#define ELEMENTO_H

struct Elemento{
    int numero; //Anho
    int stock;
};

#endif /* ELEMENTO_H */

