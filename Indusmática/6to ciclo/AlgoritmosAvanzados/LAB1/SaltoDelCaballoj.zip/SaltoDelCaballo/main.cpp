/* 
 * File:   main.cpp
 * Author: Flavio Silva Vasquez
 *
 * Created on 20 de agosto de 2025, 15:19
 */

#include <iomanip>
#include <iostream>
#include <fstream>
using namespace std;
#define MAX 8
#define MAX_MOV 8

int mov[MAX][2];
int tablero[MAX][MAX];

void matrizmovimientos(){
    mov[0][0]=-2;mov[0][1]=1;
    mov[1][0]=-1;mov[1][1]=2;
    mov[2][0]=1;mov[2][1]=2;
    mov[3][0]=2;mov[3][1]=1;
    mov[4][0]=2;mov[4][1]=-1;
    mov[5][0]=1;mov[5][1]=-2;
    mov[6][0]=-1;mov[5][1]=-2;
    mov[7][0]=-2;mov[7][1]=-1;
}

void inicializa(){
    for(int i=0;i<MAX;i++)
        for (int j = 0; j < MAX; j++)
            tablero[i][j]=0;
}

int esValido(int x,int y){
    if(x<MAX and y<MAX and 0<=x and 0<=y and tablero[x][y]==0) return 1;
    return 0;
}

int saltoCaballo(int x,int y,int nmovi){
    if((MAX*MAX)+1 == nmovi)
        return 1;
    
    for (int i = 0; i < MAX_MOV; i++) {
        int nx = x+mov[i][0];
        int ny = y+mov[i][1];
        if(esValido(nx,ny)){
            tablero[nx][ny]=nmovi;
            if(saltoCaballo(nx,ny,nmovi+1))
                return 1;
            tablero[nx][ny]=0;
        }
    }
    
    return 0;
}

void imprime(){
    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
            cout<<tablero[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(int argc, char** argv) {
    matrizmovimientos();
    inicializa();
    tablero[0][0]=1;
    int hola = saltoCaballo(0,0,2);
    imprime();
    return 0;
}

