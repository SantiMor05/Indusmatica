/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;
#include "Funciones.h"
#define MAXIMO_LINEA 111
#define NO_ENCONTRADO -1
#define MAXIMO_NOMBRE_APELLIDO_ALUMNOS 42

void ingresarCodigoFacultad(int &codigoFacultad){
    
    while(true){
       cout << "Ingrese el codigo de una facultad que desee revisar: ";
       cin >> codigoFacultad;
       if(codigoFacultad >= 100000 and codigoFacultad < 1000000) break;
       else cout << "Codigo no reconocido, ingrese nuevamente." << endl << endl;
    }
    
}

void hallarNombreFacultad(int codigoFacultad, char *arrNombreFacultad){
    
    ifstream archFacultades("Facultades.txt", ios::in);
    if(not archFacultades.is_open()){
        cout << "ERROR: El archivo Facultades.txt no se puede abrir." << endl;
        exit(1);
    }
    
    int codigoFacultadActual;
    while(true){
        
        archFacultades >> arrNombreFacultad;
        if(archFacultades.eof()) break;
        archFacultades >> codigoFacultadActual;
        
        if(codigoFacultadActual == codigoFacultad){
            quitarGuionFacultad(arrNombreFacultad);
            break;
        }
    }
            
}

void quitarGuionFacultad(char *arrNombreFacultad){
    
    for(int i = 0; arrNombreFacultad[i]; i++){
        if(arrNombreFacultad[i] == '_') arrNombreFacultad[i] = ' ';
    }
    
}

void cargarArreglosAlumnos(int *arrCodigoAlumnos, int *arrNumCursos, double *arrSumaPonderada, double *arrNumCreditos, int &cantidadAlumnos){
    
    ifstream archCalificaciones("Calificaciones.txt", ios::in);
    if(not archCalificaciones.is_open()){
        cout << "ERROR: El archivo Calificaciones.txt no se puede abrir." << endl;
        exit(1);
    } 
    
    char codigoCurso[7];
    double creditosCurso;
    int codigoAlumno, notaCurso, indiceAlumno;
    while(true){
        
        archCalificaciones >> codigoCurso;
        if(archCalificaciones.eof()) break;
        archCalificaciones >> creditosCurso;
        while(true){
         
            archCalificaciones >> codigoAlumno >> notaCurso;
            indiceAlumno = busquedaBinariaPosicion(codigoAlumno, arrCodigoAlumnos, cantidadAlumnos);
            if(indiceAlumno >= 0){
                actualizarArreglosAlumnos(indiceAlumno, creditosCurso, notaCurso, arrNumCursos, arrSumaPonderada, arrNumCreditos);
            } else {
                if(cantidadAlumnos == 0) insertarPrimerAlumno(codigoAlumno, notaCurso, creditosCurso, arrCodigoAlumnos, arrNumCursos, arrSumaPonderada, arrNumCreditos, cantidadAlumnos);
                else insertarOrdenadoAlumnos(codigoAlumno, notaCurso, creditosCurso, arrCodigoAlumnos, arrNumCursos, arrSumaPonderada, arrNumCreditos, cantidadAlumnos);
            }
            if(archCalificaciones.get() == '\n') break;
        }   
    } 
    
}

int busquedaBinariaPosicion(int codigoAlumno, int *arrCodigoAlumnos, int cantidadAlumnos){
    
    int limiteSuperior, limiteInferior, puntoMedio;
    limiteInferior = 0;
    if(cantidadAlumnos == 0) limiteSuperior = cantidadAlumnos;
    else limiteSuperior = cantidadAlumnos - 1;
    
    while(true){
        
        puntoMedio = (limiteInferior + limiteSuperior) / 2;
        if(arrCodigoAlumnos[puntoMedio] == codigoAlumno) return puntoMedio;
        
        if(arrCodigoAlumnos[puntoMedio] > codigoAlumno) limiteSuperior = puntoMedio - 1;
        else  limiteInferior = puntoMedio + 1;
        
        if(limiteInferior > limiteSuperior) return NO_ENCONTRADO;
        
    }
      
}

void actualizarArreglosAlumnos(int indiceAlumno, double creditosCurso, int notaCurso, int *arrNumCursos, double *arrSumaPonderada, double *arrNumCreditos){
    
    arrNumCursos[indiceAlumno]++;
    arrSumaPonderada[indiceAlumno] += notaCurso * creditosCurso;
    arrNumCreditos[indiceAlumno] += creditosCurso;
    
}

void insertarPrimerAlumno(int codigoAlumno, int notaCurso, double creditosCurso, int *arrCodigoAlumnos, int *arrNumCursos,
                          double *arrSumaPonderada, double *arrNumCreditos, int &cantidadAlumnos){
    
    arrCodigoAlumnos[cantidadAlumnos] = codigoAlumno;
    arrNumCursos[cantidadAlumnos]++;
    arrSumaPonderada[cantidadAlumnos] = notaCurso * creditosCurso;
    arrNumCreditos[cantidadAlumnos] = creditosCurso;
    cantidadAlumnos++;
    
}

void insertarOrdenadoAlumnos(int codigoAlumno, int notaCurso, double creditosCurso, int *arrCodigoAlumnos, int *arrNumCursos,
                             double *arrSumaPonderada, double *arrNumCreditos, int &cantidadAlumnos){
    
    int i;
    for(i = cantidadAlumnos - 1; i >= 0; i--){
        
        if(arrCodigoAlumnos[i] > codigoAlumno){
            
            arrCodigoAlumnos[i + 1] = arrCodigoAlumnos[i];
            arrNumCursos[i + 1] = arrNumCursos[i];
            arrSumaPonderada[i + 1] = arrSumaPonderada[i];
            arrNumCreditos[i + 1] = arrNumCreditos[i];
            
        } else break;
        
    }
    arrCodigoAlumnos[i + 1] = codigoAlumno;
    arrNumCursos[i + 1] = 1;
    arrSumaPonderada[i + 1] = notaCurso * creditosCurso;
    arrNumCreditos[i + 1] = creditosCurso;
    cantidadAlumnos++;
}

void emitirReporteAlumnosMatriculados(int codigoFacultad, char *arrNombreFacultad, int *arrCodigoAlumnos, int *arrNumCursos,
                                      double *arrSumaPonderada, double *arrNumCreditos, int cantidadAlumnos){
    
    ifstream archAlumnos("Alumnos.txt", ios::in);
    if(not archAlumnos.is_open()){
        cout << "ERROR: El archivo Alumnos.txt no se puede abrir." << endl;
        exit(1);
    } 
    ofstream archReporteAlumnosMatriculados("ReporteDePagoPorAlumno.txt", ios::out);
    if(not archReporteAlumnosMatriculados.is_open()){
        cout << "ERROR: El archivo ReporteDePagoPorAlumno.txt no se puede abrir." << endl;
        exit(1);
    }
    
    char arrPrimerApellido[15]{}, arrSegundoApellido[15]{}, arrApellidoCompuesto[15]{}, arrPrimerNombre[15]{}, arrSegundoNombre[15]{}, arrTercerNombre[15]{};
    int codigoAlumno, codigoFacultadActual, cantidadNombreApellidoAlumno = 0, indiceAlumno;
    imprimirEncabezado(codigoFacultad, arrNombreFacultad, archReporteAlumnosMatriculados);
    while(true){
        archAlumnos >> codigoAlumno;
        if(archAlumnos.eof()) break;
        actualizarArreglosAlumnos(archAlumnos, arrPrimerApellido, arrSegundoApellido, arrApellidoCompuesto, arrPrimerNombre, arrSegundoNombre, arrTercerNombre, cantidadNombreApellidoAlumno);
        archAlumnos >> codigoFacultadActual;
        if(codigoFacultadActual == codigoFacultad){
            indiceAlumno = busquedaBinariaPosicion(codigoAlumno, arrCodigoAlumnos, cantidadAlumnos);
            if(indiceAlumno >= 0) imprimirDatosAlumno(indiceAlumno, arrCodigoAlumnos, arrNumCursos, arrSumaPonderada, arrNumCreditos, arrPrimerApellido, arrSegundoApellido, arrApellidoCompuesto,
                                  arrPrimerNombre, arrSegundoNombre, arrTercerNombre, cantidadNombreApellidoAlumno, archReporteAlumnosMatriculados);
        }
    }
    imprimirLinea('=', MAXIMO_LINEA, archReporteAlumnosMatriculados);
}

void imprimirEncabezado(int codigoFacultad, char *arrNombreFacultad, ofstream &archReporteAlumnosMatriculados){
    
    archReporteAlumnosMatriculados << setprecision(2) << fixed;
    archReporteAlumnosMatriculados << setw(67) << "INSTITUCION EDUCATIVA TP" << endl;
    archReporteAlumnosMatriculados << setw(78) << "PROMEDIO PONDERADO DE LOS ALUMNOS MATRICULADOS" << endl;
    archReporteAlumnosMatriculados << setw(62) << "CICLO: 2024-1"  << endl;
    
    if(codigoFacultad == 400111) archReporteAlumnosMatriculados << setw(65);
    else if(codigoFacultad == 200451) archReporteAlumnosMatriculados << setw(69);
    else if(codigoFacultad == 100456) archReporteAlumnosMatriculados << setw(67);
    else if(codigoFacultad == 500017) archReporteAlumnosMatriculados << setw(66);
    else archReporteAlumnosMatriculados << setw(64);
    
    archReporteAlumnosMatriculados << arrNombreFacultad << endl;
    imprimirLinea('=', MAXIMO_LINEA, archReporteAlumnosMatriculados);
    archReporteAlumnosMatriculados << setw(11) << "ALUMNO" << setw(51) << "Nro. de Cursos" << setw(16) << "Suma Ponderada"
                                   << setw(17) << "Nro. de Creditos" << setw(16) << "Prom Ponderado" << endl;
    imprimirLinea('-', MAXIMO_LINEA, archReporteAlumnosMatriculados);
    
}

void imprimirLinea(char caracter, int cantidad, ofstream &archReporteAlumnosMatriculados){
    
    for(int i = 0; i <= cantidad; i++) archReporteAlumnosMatriculados.put(caracter);
    archReporteAlumnosMatriculados << endl;   
    
}

void actualizarArreglosAlumnos(ifstream &archAlumnos, char *arrPrimerApellido, char *arrSegundoApellido, char *arrApellidoCompuesto,
                               char *arrPrimerNombre, char *arrSegundoNombre, char *arrTercerNombre, int &cantidadNombreApellidoAlumno){
    
    char c, letraNombre;
    
    reiniciarDatosLetrasAlumno(arrPrimerNombre, arrSegundoNombre, arrTercerNombre, arrPrimerApellido, arrSegundoApellido, arrApellidoCompuesto);
    archAlumnos >> ws;
    cantidadNombreApellidoAlumno = 0;
    guardarLetrasArregloApellido(archAlumnos, arrPrimerApellido, cantidadNombreApellidoAlumno, '/');
    guardarLetrasArregloApellido(archAlumnos, arrSegundoApellido, cantidadNombreApellidoAlumno, '/');
    
    c = archAlumnos.get();
    if(c == 'L'){
        archAlumnos.unget();
        guardarLetrasArregloCompuesto(archAlumnos, arrApellidoCompuesto, cantidadNombreApellidoAlumno);
    } else archAlumnos.unget();
    
    guardarLetrasArregloNombre(archAlumnos, arrPrimerNombre, cantidadNombreApellidoAlumno, letraNombre);
    if(letraNombre == '-'){
        guardarLetrasArregloNombre(archAlumnos, arrSegundoNombre, cantidadNombreApellidoAlumno, letraNombre);
        
        if(letraNombre == '-'){
            guardarLetrasArregloNombre(archAlumnos, arrTercerNombre, cantidadNombreApellidoAlumno, letraNombre);
        }
    }
    
}

void reiniciarDatosLetrasAlumno(char *arrPrimerNombre, char *arrSegundoNombre, char *arrTercerNombre, char *arrPrimerApellido,
                                char *arrSegundoApellido, char *arrApellidoCompuesto){
    
    reiniciarArregloNulo(arrPrimerNombre);
    reiniciarArregloNulo(arrSegundoNombre);
    reiniciarArregloNulo(arrTercerNombre);
    reiniciarArregloNulo(arrPrimerApellido);
    reiniciarArregloNulo(arrSegundoApellido);
    reiniciarArregloNulo(arrApellidoCompuesto);
    
}

void reiniciarArregloNulo(char *arreglo){
    
    for(int i = 0; arreglo[i]; i++){
        
        arreglo[i] = 0;
        
    }
    
}

void guardarLetrasArregloApellido(ifstream &archAlumnos, char *arrApellido, int &cantidadNombreApellidoAlumno, char caracter){
    
    int i = 0;
    char letraApellido;
    
    while(true){
        
        letraApellido = archAlumnos.get();
        if(letraApellido == caracter) break;
        arrApellido[i] = letraApellido;
        i++;
        cantidadNombreApellidoAlumno++;
        
    }
    
    arreglarLetras(arrApellido);
    cantidadNombreApellidoAlumno++;
    
}

void arreglarLetras(char *arrApellido){
    
    for(int i = 0; arrApellido[i]; i++){
        
        if(i != 0) {
         
            if (arrApellido[i] >= 'A' && arrApellido[i] <= 'Z') {
                arrApellido[i] += ('a' - 'A');
            }
        }
        
    }
    
}

void guardarLetrasArregloCompuesto(ifstream &archAlumnos, char *arrApellidoCompuesto, int &cantidadNombreApellidoAlumno){
    
    int i = 0;
    char letraNombreApellido;
    bool primerSigno = true;
    
    while(true){
        
        letraNombreApellido = archAlumnos.get();
        if(letraNombreApellido == '-'){
            if(primerSigno) primerSigno = false;
            else break;
        } 
        arrApellidoCompuesto[i] = letraNombreApellido;
        i++;
        cantidadNombreApellidoAlumno++;
        
    }
    
    arreglarLetrasCompuesto(arrApellidoCompuesto);
    cantidadNombreApellidoAlumno++;
    
}

void arreglarLetrasCompuesto(char *arrApellidoCompuesto){
    
    bool primeraLetra = true;
    
    for(int i = 0; arrApellidoCompuesto[i]; i++){
        
        if(primeraLetra) primeraLetra = false;
        else {
            
            if(arrApellidoCompuesto[i] == '-') {
                
                arrApellidoCompuesto[i] = ' ';
                primeraLetra = true;
                
            } else arrApellidoCompuesto[i] += ('a' - 'A');
            
        }
        
    }
    
}

void guardarLetrasArregloNombre(ifstream &archAlumnos, char *arrNombre, int &cantidadNombreApellidoAlumno, char &letraNombre){
    
    int i = 0;
    
    while(true){
        
        letraNombre = archAlumnos.get();
        if(letraNombre == '-' or letraNombre == ' ') break;
        arrNombre[i] = letraNombre;
        i++;
        cantidadNombreApellidoAlumno++;
        
    }
    
    arreglarLetras(arrNombre);
    cantidadNombreApellidoAlumno++;
    
}

void imprimirDatosAlumno(int indiceAlumno, int *arrCodigoAlumnos, int *arrNumCursos, double *arrSumaPonderada, double *arrNumCreditos, char *arrPrimerApellido,
                         char *arrSegundoApellido, char *arrApellidoCompuesto, char *arrPrimerNombre, char *arrSegundoNombre,
                         char *arrTercerNombre, int cantidadNombreApellidoAlumno, ofstream &archReporteAlumnosMatriculados){
    
   double promedioPonderado;
   promedioPonderado = (double) arrSumaPonderada[indiceAlumno] / arrNumCreditos[indiceAlumno];
   
   archReporteAlumnosMatriculados << arrCodigoAlumnos[indiceAlumno] << " - " << arrPrimerNombre;
   if(arrSegundoNombre[0] != '\0') archReporteAlumnosMatriculados << " " << arrSegundoNombre;
   if(arrTercerNombre[0] != '\0') archReporteAlumnosMatriculados << " " << arrTercerNombre;
   
   archReporteAlumnosMatriculados << " " <<  arrPrimerApellido << " " << arrSegundoApellido << " ";
   if(arrApellidoCompuesto[0] != '\0') archReporteAlumnosMatriculados << arrApellidoCompuesto << " ";
   
   for(int i = 0; i <= MAXIMO_NOMBRE_APELLIDO_ALUMNOS - cantidadNombreApellidoAlumno; i++) archReporteAlumnosMatriculados.put(' ');
   archReporteAlumnosMatriculados << setw(2) << arrNumCursos[indiceAlumno] << setw(19) << arrSumaPonderada[indiceAlumno] << setw(16)
                                  << arrNumCreditos[indiceAlumno] << setw(16) << promedioPonderado << endl;
            
   
}

