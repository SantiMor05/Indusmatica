/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: PC
 *
 * Created on 22 de octubre de 2024, 17:44
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void ingresarCodigoFacultad(int &codigoFacultad);
void hallarNombreFacultad(int codigoFacultad, char *arrNombreFacultad);
void quitarGuionFacultad(char *arrNombreFacultad);
void cargarArreglosAlumnos(int *arrCodigoAlumnos, int *arrNumCursos, double *arrSumaPonderada, double *arrNumCreditos, int &cantidadAlumnos);
int busquedaBinariaPosicion(int codigoAlumno, int *arrCodigoAlumnos, int cantidadAlumnos);
void actualizarArreglosAlumnos(int indiceAlumno, double creditosCurso, int notaCurso, int *arrNumCursos, double *arrSumaPonderada, double *arrNumCreditos);
void insertarPrimerAlumno(int codigoAlumno, int notaCurso, double creditosCurso, int *arrCodigoAlumnos, int *arrNumCursos,
                          double *arrSumaPonderada, double *arrNumCreditos, int &cantidadAlumnos);
void insertarOrdenadoAlumnos(int codigoAlumno, int notaCurso, double creditosCurso, int *arrCodigoAlumnos, int *arrNumCursos,
                             double *arrSumaPonderada, double *arrNumCreditos, int &cantidadAlumnos);
void emitirReporteAlumnosMatriculados(int codigoFacultad, char *arrNombreFacultad, int *arrCodigoAlumnos, int *arrNumCursos,
                                      double *arrSumaPonderada, double *arrNumCreditos, int cantidadAlumnos);
void imprimirEncabezado(int codigoFacultad, char *arrNombreFacultad, ofstream &archReporteAlumnosMatriculados);
void imprimirLinea(char caracter, int cantidad, ofstream &archReporteAlumnosMatriculados);
void actualizarArreglosAlumnos(ifstream &archAlumnos, char *arrPrimerApellido, char *arrSegundoApellido, char *arrApellidoCompuesto,
                               char *arrPrimerNombre, char *arrSegundoNombre, char *arrTercerNombre, int &cantidadNombreApellidoAlumno);
void reiniciarDatosLetrasAlumno(char *arrPrimerNombre, char *arrSegundoNombre, char *arrTercerNombre, char *arrPrimerApellido,
                                char *arrSegundoApellido, char *arrApellidoCompuesto);
void reiniciarArregloNulo(char *arreglo);
void guardarLetrasArregloApellido(ifstream &archAlumnos, char *arrApellido, int &cantidadNombreApellidoAlumno, char caracter);
void arreglarLetras(char *arrApellido);
void guardarLetrasArregloCompuesto(ifstream &archAlumnos, char *arrApellidoCompuesto, int &cantidadNombreApellidoAlumno);
void arreglarLetrasCompuesto(char *arrApellidoCompuesto);
void guardarLetrasArregloNombre(ifstream &archAlumnos, char *arrNombre, int &cantidadNombreApellidoAlumno, char &letraNombre);
void imprimirDatosAlumno(int indiceAlumno, int *arrCodigoAlumnos, int *arrNumCursos, double *arrSumaPonderada, double *arrNumCreditos, char *arrPrimerApellido,
                         char *arrSegundoApellido, char *arrApellidoCompuesto, char *arrPrimerNombre, char *arrSegundoNombre,
                         char *arrTercerNombre, int cantidadNombreApellidoAlumno, ofstream &archReporteAlumnosMatriculados);
void imprimirArregloLetras(char *arreglo, ofstream &archReporteAlumnosMatriculados);

#endif /* FUNCIONES_H */

