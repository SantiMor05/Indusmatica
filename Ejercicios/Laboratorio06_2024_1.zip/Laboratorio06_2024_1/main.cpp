/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: PC
 *
 * Created on 22 de octubre de 2024, 17:04
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;
#include "Funciones.h"
#define TAMANO_ARREGLO_ALUMNOS 75

/*
 * 
 */
int main(int argc, char** argv) {

    char arrNombreFacultad[30];
    int codigoFacultad;
    
    int arrCodigoAlumnos[TAMANO_ARREGLO_ALUMNOS], cantidadAlumnos = 0, arrNumCursos[TAMANO_ARREGLO_ALUMNOS]{};
    double arrSumaPonderada[TAMANO_ARREGLO_ALUMNOS]{}, arrNumCreditos[TAMANO_ARREGLO_ALUMNOS]{}; 
    
    ingresarCodigoFacultad(codigoFacultad);
    hallarNombreFacultad(codigoFacultad, arrNombreFacultad);
    cargarArreglosAlumnos(arrCodigoAlumnos, arrNumCursos, arrSumaPonderada, arrNumCreditos, cantidadAlumnos);
    emitirReporteAlumnosMatriculados(codigoFacultad, arrNombreFacultad, arrCodigoAlumnos, arrNumCursos,
                                     arrSumaPonderada, arrNumCreditos, cantidadAlumnos);
    
    return 0;
    
}

